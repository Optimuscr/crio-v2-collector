CRIO v2 — v0.3 RAILWAY KURULUMU
1. Ayrı CRIO service/repo kullan; mevcut Optimus/OTI collector'a dokunma.
2. Persistent Railway volume'ü /data'ya mount et; CRIO_STATE_PATH=/data/crio/state.
3. python3 tests/run_tests.py 8/8 geçmeli.
4. src/physical_restart_test.py /data/crio/state iki ayrı process ile geçmeli; probe production state'e yazılmaz.
5. İlk gerçek cycle: python3 src/collector_daemon.py --once. Spot/Perp/OI/Funding/Depth/Spread receiptleri ve observations oluşmalı.
6. health monitor duplicate/future timestamp=0 göstermeli.
7. Ancak bunlardan sonra daemon sürekli çalıştırılır; ilk tam 4S +2dk prospective başlangıçtır.
8. Work yalnız denetim/analizdir; state sahibi değildir.
9. AVAX/NEAR ve v2 skor/AL kapalı.
NOT: Otomatik deploy şu an yapılmadı; Railway GitHub deploy somut connected repo gerektiriyor ve bağlı GitHub hesabında repo görünmüyor. Mevcut Optimus collector servisini değiştirmedim.
