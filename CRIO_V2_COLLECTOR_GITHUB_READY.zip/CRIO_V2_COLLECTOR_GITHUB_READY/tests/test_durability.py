import importlib.util,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location("m",root/"src/append_only_ledger.py");m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
C=json.load(open(root/"contracts/UNIFIED_DATA_CONTRACT.json"))
def env(t=1000):
 return {"asset":"BTCUSDT","feature":"funding_rate","value":.0001,"source_id":"binance","source_timestamp_ms":t,"collected_at_ms":t+10,"raw_receipt_sha256":"a"*64}
def test_duplicate_observation_idempotent(tmp_path):
 assert m.ingest(env(),tmp_path)["inserted"] is True
 assert m.ingest(env(),tmp_path)["inserted"] is False
 assert len((tmp_path/"observations.jsonl").read_text().splitlines())==1
def test_duplicate_event_idempotent(tmp_path):
 e={"asset":"BTCUSDT","event_timestamp_ms":2000,"trigger":"MOST_CONTEXT"}
 assert m.bind_event(e,tmp_path,C)["inserted"] is True
 assert m.bind_event(e,tmp_path,C)["inserted"] is False
 assert len((tmp_path/"events.jsonl").read_text().splitlines())==1
def test_restart_recovery(tmp_path):
 m.ingest(env(1000),tmp_path)
 # emulate process restart by reloading module
 sp2=importlib.util.spec_from_file_location("m2",root/"src/append_only_ledger.py");m2=importlib.util.module_from_spec(sp2);sp2.loader.exec_module(m2)
 assert m2.ingest(env(2000),tmp_path)["inserted"] is True
 assert len((tmp_path/"observations.jsonl").read_text().splitlines())==2
def test_atomic_checkpoint(tmp_path):
 p=tmp_path/"checkpoint.json";m.atomic_json(p,{"cycle":1});assert json.load(open(p))["cycle"]==1
