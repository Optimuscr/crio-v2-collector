import importlib.util,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location("m",root/"src/append_only_ledger.py");m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
C=json.load(open(root/"contracts/UNIFIED_DATA_CONTRACT.json"))
def env(t=1000):
 return {"asset":"BTCUSDT","feature":"funding_rate","value":0.0001,"source_id":"binance","source_timestamp_ms":t,"collected_at_ms":t+10,"raw_receipt_sha256":"a"*64}
def test_ingest_append(tmp_path):
 m.ingest(env(),tmp_path);m.ingest(env(2000),tmp_path)
 assert len((tmp_path/"observations.jsonl").read_text().splitlines())==2
def test_future_source_rejected(tmp_path):
 x=env();x["source_timestamp_ms"]=2000;x["collected_at_ms"]=1000
 try:m.ingest(x,tmp_path);assert False
 except ValueError as e:assert str(e)=="SOURCE_AFTER_COLLECTION"
def test_point_in_time_binding(tmp_path):
 m.ingest(env(1000),tmp_path);m.ingest(env(3000),tmp_path)
 e={"asset":"BTCUSDT","event_timestamp_ms":2000,"trigger":"MOST_CONTEXT"}
 r=m.bind_event(e,tmp_path,C)
 assert r["features"]["funding_rate"]["source_timestamp_ms"]==1000
def test_missing_not_zero(tmp_path):
 e={"asset":"BTCUSDT","event_timestamp_ms":2000,"trigger":"MOST_CONTEXT"}
 r=m.bind_event(e,tmp_path,C)
 assert r["features"]["open_interest_value"]["value"] is None
