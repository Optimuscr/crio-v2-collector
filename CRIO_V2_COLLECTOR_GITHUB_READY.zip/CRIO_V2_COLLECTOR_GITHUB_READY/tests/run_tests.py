#!/usr/bin/env python3
import importlib.util, json, tempfile, shutil, hashlib, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
LEDGER=ROOT/"src"/"append_only_ledger.py"
CONTRACT=ROOT/"contracts"/"UNIFIED_DATA_CONTRACT.json"

def loadmod(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m); return m

m=loadmod("ledger",LEDGER)
C=json.load(open(CONTRACT,encoding="utf-8"))

def env(t=1000):
    return {
      "asset":"BTCUSDT","feature":"funding_rate","value":0.0001,
      "source_id":"binance","source_timestamp_ms":t,"collected_at_ms":t+10,
      "raw_receipt_sha256":"a"*64
    }

tests=[]

def run(name,fn):
    try:
        fn()
        tests.append({"test":name,"status":"PASS"})
    except Exception as e:
        tests.append({"test":name,"status":"FAIL","error":repr(e)})

def t_append_only():
    d=Path(tempfile.mkdtemp())
    try:
        assert m.ingest(env(1000),d)["inserted"] is True
        assert m.ingest(env(2000),d)["inserted"] is True
        assert len((d/"observations.jsonl").read_text().splitlines())==2
    finally: shutil.rmtree(d)

def t_future_rejected():
    d=Path(tempfile.mkdtemp())
    try:
        x=env(); x["source_timestamp_ms"]=2000; x["collected_at_ms"]=1000
        ok=False
        try: m.ingest(x,d)
        except ValueError as e: ok=str(e)=="SOURCE_AFTER_COLLECTION"
        assert ok
    finally: shutil.rmtree(d)

def t_pit_binding():
    d=Path(tempfile.mkdtemp())
    try:
        m.ingest(env(1000),d); m.ingest(env(3000),d)
        e={"asset":"BTCUSDT","event_timestamp_ms":2000,"trigger":"MOST_CONTEXT"}
        r=m.bind_event(e,d,C)
        assert r["features"]["funding_rate"]["source_timestamp_ms"]==1000
    finally: shutil.rmtree(d)

def t_missing_none():
    d=Path(tempfile.mkdtemp())
    try:
        e={"asset":"BTCUSDT","event_timestamp_ms":2000,"trigger":"MOST_CONTEXT"}
        r=m.bind_event(e,d,C)
        assert r["features"]["open_interest_value"]["value"] is None
    finally: shutil.rmtree(d)

def t_duplicate_obs():
    d=Path(tempfile.mkdtemp())
    try:
        assert m.ingest(env(),d)["inserted"] is True
        assert m.ingest(env(),d)["inserted"] is False
        assert len((d/"observations.jsonl").read_text().splitlines())==1
    finally: shutil.rmtree(d)

def t_duplicate_event():
    d=Path(tempfile.mkdtemp())
    try:
        e={"asset":"BTCUSDT","event_timestamp_ms":2000,"trigger":"MOST_CONTEXT"}
        assert m.bind_event(e,d,C)["inserted"] is True
        assert m.bind_event(e,d,C)["inserted"] is False
        assert len((d/"events.jsonl").read_text().splitlines())==1
    finally: shutil.rmtree(d)

def t_restart_recovery():
    d=Path(tempfile.mkdtemp())
    try:
        m.ingest(env(1000),d)
        before=(d/"observations.jsonl").read_bytes()
        m2=loadmod("ledger2",LEDGER)
        assert m2.ingest(env(2000),d)["inserted"] is True
        lines=(d/"observations.jsonl").read_text().splitlines()
        assert len(lines)==2
        assert before in (d/"observations.jsonl").read_bytes()
    finally: shutil.rmtree(d)

def t_atomic_checkpoint():
    d=Path(tempfile.mkdtemp())
    try:
        p=d/"checkpoint.json"; m.atomic_json(p,{"cycle":1})
        assert json.load(open(p))["cycle"]==1
    finally: shutil.rmtree(d)

for name,fn in [
 ("append_only",t_append_only),("future_timestamp_rejected",t_future_rejected),
 ("point_in_time_binding",t_pit_binding),("missing_not_zero",t_missing_none),
 ("duplicate_observation_idempotent",t_duplicate_obs),("duplicate_event_idempotent",t_duplicate_event),
 ("restart_recovery",t_restart_recovery),("atomic_checkpoint",t_atomic_checkpoint)
]:
    run(name,fn)

result={"runner":"stdlib_only","external_dependencies":False,
        "passed":sum(x["status"]=="PASS" for x in tests),
        "failed":sum(x["status"]=="FAIL" for x in tests),
        "tests":tests}
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(0 if result["failed"]==0 else 1)
